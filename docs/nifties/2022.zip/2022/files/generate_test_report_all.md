```python

#file generate_test_report_all

{% include_relative generate_test_report_all.py %}
```