```
#file union_test_pytest_output.txt

{% include_relative pytests-for_testing_reports/output_union_test.txt %}
```
