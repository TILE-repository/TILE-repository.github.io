```python

#file grammmar.lark

{% include_relative grammar.lark %}
```