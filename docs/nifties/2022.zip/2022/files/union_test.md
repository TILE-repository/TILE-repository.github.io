```python

#file union_test.py

{% include_relative pytests-for_testing_reports/union_test.py %}
```